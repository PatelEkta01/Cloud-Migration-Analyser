# inference.py - Optimized for SageMaker
import json
import boto3
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
import os

# Global variables to store loaded models/data
model = None
faiss_index = None
texts = None
sagemaker_runtime = None

def model_fn(model_dir):
    """
    Load model and data ONCE when container starts (not during each inference)
    This prevents timeout issues
    """
    global model, faiss_index, texts, sagemaker_runtime
    
    print("🚀 Loading models and building FAISS index...")
    
    # 1. Load SentenceTransformer model
    model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    
    # 2. Load knowledge base from model artifacts
    knowledge_path = os.path.join(model_dir, "knowledge_vectors.json")
    with open(knowledge_path, "r") as f:
        raw = json.load(f)
    
    texts = raw["text_chunks"]
    vectors = np.array(raw["vectors"]).astype("float32")
    
    # 3. Build FAISS index ONCE
    faiss_index = faiss.IndexFlatL2(vectors.shape[1])
    faiss_index.add(vectors)
    
    # 4. Initialize SageMaker runtime client
    sagemaker_runtime = boto3.client("sagemaker-runtime")
    
    print("✅ Model loading complete!")
    return {"status": "loaded"}

def input_fn(request_body, request_content_type):
    """Parse input request"""
    if request_content_type == "application/json":
        return json.loads(request_body)
    else:
        raise ValueError(f"Unsupported content type: {request_content_type}")

def predict_fn(input_data, model_data):
    """
    Fast inference using pre-loaded models
    """
    global model, faiss_index, texts, sagemaker_runtime
    
    try:
        # Extract query from input
        query = input_data.get("query", "")
        top_k = input_data.get("top_k", 3)
        flan_endpoint = input_data.get("flan_endpoint", "flan-t5-base-endpoint-v1")
        
        # 1. Embed query (fast because model is pre-loaded)
        query_vec = model.encode(query).reshape(1, -1).astype("float32")
        
        # 2. FAISS search (very fast)
        D, I = faiss_index.search(query_vec, k=top_k)
        
        # 3. Get matching text chunks
        context_chunks = [texts[i] for i in I[0]]
        
        # 4. Build prompt
        context_text = "\n".join(context_chunks)
        prompt = f"""Context:
{context_text}

Question:
{query}

Answer:"""
        
        # 5. Call FLAN-T5 endpoint
        response = sagemaker_runtime.invoke_endpoint(
            EndpointName=flan_endpoint,
            ContentType="application/json",
            Body=json.dumps({
                "inputs": prompt,
                "parameters": {
                    "max_length": 200,
                    "temperature": 0.7,
                    "do_sample": True
                }
            })
        )
        
        # 6. Parse result
        result = json.loads(response["Body"].read())
        final_answer = result[0]["generated_text"]
        
        return {
            "answer": final_answer,
            "retrieved_chunks": context_chunks,
            "similarity_scores": D[0].tolist(),
            "chunk_indices": I[0].tolist()
        }
        
    except Exception as e:
        return {"error": str(e)}

def output_fn(prediction, accept):
    """Format output response"""
    if accept == "application/json":
        return json.dumps(prediction), accept
    else:
        raise ValueError(f"Unsupported accept type: {accept}")